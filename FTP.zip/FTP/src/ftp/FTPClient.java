/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*package FTP;

import java.net.*; 
import java.io.*; 
import java.util.Scanner;
//import java.io.DataInputStream;
//import java.io.DataOutputStream;
//import java.net.Socket;
//import java.util.Scanner;

/**
 *
 * @author Vamsi
 */

  
/*public class FTPClient 
{ 
    // initialize socket and input output streams 
    private Socket socket            = null; 
    private DataInputStream  dis   = null; 
    private DataOutputStream dos     = null; 
  
    public FTPClient(String address, int port) throws IOException 
    { 
        try
        { 
            socket = new Socket(address, port); 
            Scanner sc = new Scanner(System.in);
            dis  = new DataInputStream(socket.getInputStream()); 
            dos    = new DataOutputStream(socket.getOutputStream());
            String request = null;
            String response = null;
            dos.writeUTF("");
            do{                
                response = dis.readUTF();
                System.out.println(response);
                request = sc.nextLine();
                dos.writeUTF(String.valueOf(request));
            }
            while(!request.equals("logout") && !request.equals("exit"));            
            socket.close();
        } 
        catch(Exception e) 
        { 
            System.out.println(e); 
        } 
    } 
  
    public static void main(String args[]) throws IOException 
    { 
        FTPClient client = new FTPClient("localhost", 21); 
    } 
}*/
package FTP;

import java.net.*; 
import java.io.*; 
import java.util.Scanner;
//import java.io.DataInputStream;
//import java.io.DataOutputStream;
//import java.net.Socket;
//import java.util.Scanner;

/**
 *
 * @author Vamsi
 */
public class FTPClient 
{ 
    // initialize socket and input output streams 
    private Socket socket          = null; 
    private DataInputStream  dis   = null; 
    private DataOutputStream dos   = null; 
   String path="C:\\root\\dir\\root\\";
    public FTPClient(String address, int port) throws IOException 
    { 
        try
        { 
            socket = new Socket(address, port); 
            Scanner sc = new Scanner(System.in);
            dis  = new DataInputStream(socket.getInputStream()); 
            dos  = new DataOutputStream(socket.getOutputStream());
            String request  = null;
            String response = null;
            dos.writeUTF("");
            do
            {   
                String response1 = dis.readUTF();
                //System.out.println(response1+" hh");
                String[] arr = response1.split(",");
                //System.out.println(arr.length);
                if(arr.length>1)
                {
                    System.out.println("please login");
                    response = arr[1];
                }else{
                    //System.out.println(arr[0]);
                    response = arr[0];
                }
                System.out.print(response);
                request  = sc.nextLine();
                String [] tokens  = request.split(" ");
                if(arr.length == 1)
                {
                    if(tokens[0].equals("delete"))
                    {
                        dos.writeUTF(String.valueOf(request));
                        response=dis.readUTF();
                        System.out.println(response);
                        System.out.println(dis.readUTF());
                    }
                    else if(tokens[0].equals("rename"))
                    {
                        dos.writeUTF(String.valueOf(request));
                        response=dis.readUTF();
                        System.out.println(response);
                        System.out.println(dis.readUTF());
                        System.out.println(dis.readUTF());
                    }
                    else if(tokens[0].equals("move"))
                    {
                        dos.writeUTF(String.valueOf(request));
                        response=dis.readUTF();
                        System.out.println(response);
                        System.out.println(dis.readUTF());
                        System.out.println(dis.readUTF());
                    }
                    else if(tokens[0].equals("newdir"))
                    {
                        dos.writeUTF(String.valueOf(request));
                        response=dis.readUTF();
                        System.out.println(response);
                        System.out.println(dis.readUTF());
                        System.out.println(dis.readUTF());
                    }
                    else if(tokens[0].equals("changedir"))
                    {
                        dos.writeUTF(String.valueOf(request));
                        response=dis.readUTF();
                        System.out.println(response);
                        System.out.println(dis.readUTF());
                        System.out.println(dis.readUTF());
                    }
                    else if(tokens[0].equals("changedir"))
                    {
                        dos.writeUTF(String.valueOf(request));
                        response=dis.readUTF();
                        System.out.println(response);
                        System.out.println(dis.readUTF());
                        System.out.println(dis.readUTF());
                    }
                    else if(tokens[0].equals("newfile"))
                    {
                        dos.writeUTF(String.valueOf(request));
                        response=dis.readUTF();
                        System.out.println(response);
                        System.out.println(dis.readUTF());
                        System.out.println(dis.readUTF());
                    }
                    else if(tokens[0].equals("delete"))
                    {
                         dos.writeUTF(String.valueOf(request));
                        response=dis.readUTF();
                        System.out.println(response);
                        System.out.println(dis.readUTF());
                        System.out.println(dis.readUTF());
                    }
                     else if(tokens[0].equals("rename"))
                    {
                        dos.writeUTF(String.valueOf(request));
                        response=dis.readUTF();
                        System.out.println(response);
                        System.out.println(dis.readUTF());
                        System.out.println(dis.readUTF());
                    }
                    else if(tokens[0].equals("upload")){
                        dos.writeUTF(String.valueOf(request));
                        response = dis.readUTF();
                        if(response.equals("success")){
                            Socket socket1 = new Socket(address, 20);
                            DataOutputStream dos1  = new DataOutputStream(socket1.getOutputStream());                       
                            File file = new File(tokens[1]); 
                            //String path=file.getAbsolutePath();
                            DataInputStream reader = new DataInputStream(new FileInputStream(file));
                                byte [] buffer = new byte[1000];
                                while(reader.read(buffer)>0)        
                                {
                                   dos1.write(buffer);
                                }     
                                //System.out.println(path);
                            dos1.close();
                            reader.close(); 
                            socket1.close();
                        }
                        dos.writeUTF("");
                    }
                    else if(tokens[0].equals("download")){
                        dos.writeUTF(String.valueOf(request));
                        response = dis.readUTF();
                        if(response.equals("success")){
                            Socket socket1 = new Socket(address, 20);
                            DataInputStream dis1  = new DataInputStream(socket1.getInputStream());                       
                            File file = new File(path+tokens[1]); 
                            //String path=file.getAbsolutePath();
                            DataOutputStream writer = new DataOutputStream(new FileOutputStream(file));
                                byte [] buffer = new byte[1000];
                                while(dis1.read(buffer)>0)        
                                {
                                   writer.write(buffer);
                                }     
                                //System.out.println(writer.toString());
                            dis1.close();
                            writer.close(); 
                            socket1.close();
                        }
                        dos.writeUTF("");
                    }


                    
                }else if(request.contains("login") || request.contains("register")){
                        dos.writeUTF(String.valueOf(request));
                    }
                else
                {
                    dos.writeUTF("nologin");
                }
            }
            while(!request.equals("logout") && !request.equals("exit"));  
            
            socket.close();
        } 
        catch(Exception e) 
        { 
            System.out.println(e); 
        } 
    }
    public static void main(String args[]) throws IOException,FileNotFoundException 
    { 
        FTPClient client = new FTPClient("localhost", 21); 
    } 
}