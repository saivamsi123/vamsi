///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package FTP;
//
////import java.net.*; 
////import java.io.*; 
//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.DataInputStream;
//import java.io.DataOutputStream;
//import java.io.File;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.net.ServerSocket;
//import java.net.Socket;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Scanner;
//import java.util.StringTokenizer;
//import javax.net.ssl.SSLServerSocket;
///**
// *
// * @author Vamsi
// */
//
//
//public class FTPServer 
//{ 
//    private Socket          socket   = null; 
//    private ServerSocket    server   = null; 
//    private DataInputStream dis      =  null; 
//    private DataOutputStream dos     = null;
//    private String path = "root:/";
//    String username="";
//    String password="";
//    File folder;
//    List<String> list=new ArrayList<String>();
//    File file;
//    String OrgPath="C:\\Users\\Vamsi\\Documents\\NetBeansProjects\\FTP";
//    public FTPServer(int port) 
//    { 
//        try
//        {
//            server = new ServerSocket(port);   
////            System.out.println("Server started"+port); 
//            System.out.println("Server is running");
//            System.out.println("Waiting for a client ..."); 
//            while(true)
//            {
//                socket = server.accept();
//                System.out.println("client connected...");
//                dis = new DataInputStream(socket.getInputStream());
//                dos = new DataOutputStream(socket.getOutputStream());
//                while(true){
//                    String in = dis.readUTF();
//                    String [] tokens = in.split(" ");
//                    file = new File("users.data");
//                    if(tokens[0].equals("logout") || tokens[0].equals("exit")){
//                        break;
//                    }
//                    //register
//                else if(tokens[0].equals("register")){
////                        file = new File("users.data");
//                    if(!file.exists()){
//                        file.createNewFile();
//                    }
//                    boolean user_exists = false;
//                    BufferedReader reader = new BufferedReader(new FileReader(file));
//                    String userLine = "";
//                    String userData = "";
//
//                    while((userLine=reader.readLine())!=null){
//                        userData+=userLine+"\n";
//                        System.out.println("User : "+userLine);
//                        //new code for validation
//                        String[] check=userLine.split(" ");
//                        for(int i=0;i<check.length;i++)
//                        {
//                            username=check[0];
//                            if(username.equalsIgnoreCase(tokens[1]))
//                            {
//                                user_exists=true;
//                            }
//                            System.out.println(username);
//                        }
//                    }
//                    reader.close();
//                    userLine = tokens[1]+" "+tokens[2]+" "+tokens[4]+" "+tokens[5];
//
//                    if(!user_exists){
//                        userData+=userLine;
//                        BufferedWriter writer = new BufferedWriter(new FileWriter(file));
//                        writer.append(userData);
//                        writer.close();
//                        dos.writeUTF("User registered successfully"+path);
//                    }
//                    else{
//                        dos.writeUTF("User Already Exists"+path);
//                    }
//                   }
//                //login
//                    else if(tokens[0].equals("login"))
//                    {
//                        BufferedReader reader = new BufferedReader(new FileReader(file));
//                        String userLine = "";
//                        String userData = "";
//                        boolean user_exists=false;
//                        while((userLine=reader.readLine())!=null)
//                        {
//                            userData+=userLine+"\n";
//                            //System.out.println("User: "+userData);
//                            //dos.writeUTF(path+username);
//                            //new code for validation
//                            String[] check=userLine.split(" ");
//                    for(int i=0;i<check.length;i++)
//                    {
//                        username=check[0];
//                        password=check[1];
//                        if(tokens[1].equalsIgnoreCase(username)&&tokens[2].equalsIgnoreCase(password))
//                        {
//                            user_exists=true;
//                            if(user_exists)
//                            {
//                               dos.writeUTF(path+""+username+">");
//                               String reply=dis.readUTF();
//                               String[] token=reply.split(" ");
//                               //ls command
//                               if(token[0].equalsIgnoreCase("list"))
//                               {
//                                   System.out.println(file.getAbsolutePath());
//                                   dos.writeUTF(file.getAbsolutePath());
//                                  folder = new File("C:\\Users\\Vamsi\\Documents\\NetBeansProjects\\FTP");
//                                File[] listOfFiles = folder.listFiles();
//                                for (int j = 0; j < listOfFiles.length; j++) {
//                                  if (listOfFiles[j].isFile()) {
//                                    String file="";
//                                    file=listOfFiles[j].getName();
//                                    dos.writeUTF("FILE:"+file);
//                                    //System.out.println("File " + listOfFiles[j].getName());
//                                  } 
//                                  else if (listOfFiles[j].isDirectory()) {
//                                      String folders="";
//                                      folders=listOfFiles[j].getName();
//                                      dos.writeUTF("FOLDERS:"+folders);
//                                    //System.out.println("Directory " + listOfFiles[j].getName());
//                                  }
//                                }
//                               }
//                               //make directory
//                            if(token[0].trim().equalsIgnoreCase("mkdir"))
//                            {
//                                String dir=token[1];
//                                File file=new File("C:\\Users\\Vamsi\\Documents\\NetBeansProjects\\FTP\\"+dir);
//                                boolean flag=false;
//                                if(!file.exists())
//                                {
//                                    flag=file.mkdir();
//                                }
//                                else
//                                {
//                                    System.out.println("Dir already exists");
//                                    flag=false;
//                                }
//                                if(flag)
//                                {
//                                    String file1=token[2];
//                                    if(file1.equalsIgnoreCase("createFile"))
//                                    {
//                                        String file2=token[3];
//                                        File file3=new File("C:\\Users\\Vamsi\\Documents\\NetBeansProjects\\FTP\\"+"dir\\"+file2);
//                                        boolean flagg=false;
//                                        if(!file3.exists())
//                                        {
//                                            flagg=file3.createNewFile();
//                                            
//                                        }
//                                        else
//                                        {
//                                            System.out.println("File is not created");
//                                            flagg=false;
//                                        }
//                                        if(flagg)
//                                        {
//                                            dos.writeUTF("File is created"+file3);
//                                            
//                                        }
//                                        else
//                                        {
//                                            dos.writeUTF("file is not created");
//                                        }
//
//                                    }
//                                    dos.writeUTF("Directory is created"+file.getAbsolutePath());
//                                }
//                                else
//                                {
//                                    dos.writeUTF("Directory is not created");
//                                }
//                            }
//                            //change directory
//                            if(token[0].trim().equalsIgnoreCase("cd.."))
//                            {
//                                File file=new File(OrgPath);
//                            }
//                            //remove directory
//                            if(token[0].trim().equalsIgnoreCase("rmdir"))
//                            {
//                                String dir=token[1];
//                                File file=new File("C:\\Users\\Vamsi\\Documents\\NetBeansProjects\\FTP\\"+dir);
//                                boolean flag=false;
//                                if(file.exists())
//                                {
//                                    flag=file.delete();
//                                }
//                                else
//                                {
//                                    System.out.println("Dir not exists");
//                                    flag=false;
//                                }
//                                if(flag)
//                                {
//                                    dos.writeUTF("Directory is deleted"+file.getAbsolutePath());
//                                }
//                                else
//                                {
//                                    dos.writeUTF("Directory is not deleted");
//                                }
//                            } 
//                            
//                            
//                            }
//                            
//                            else
//                            {
//                               dos.writeUTF("Retry with correct credentials");
//                            }
//                        }
//
//                        }
//                    }
//                        reader.close();
//                        
//                    }
//                    
//                    else{
//                        dos.writeUTF(path); 
//                    }
//                }
//                System.out.println("Client Disconnected");
//                socket.close();
//            }
//            
//            
//            
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            
//        }
//    } 
//  
//    public static void main(String args[]) 
//    { 
//        FTPServer server = new FTPServer(21); 
//    } 
//} 

package FTP;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author Vamsi
 */
public class FTPServer 
{ 
    private Socket           socket   = null; 
    private ServerSocket     server   = null; 
    private DataInputStream  dis      =  null; 
    private DataOutputStream dos      = null;
    private boolean login_success =false;
    private Socket           socket1   = null; 
    private ServerSocket     server1   = null; 
    private DataInputStream  dis1      =  null; 
    private DataOutputStream dos1      = null;
    
    private String path = "\nMSITFTP:\\>";
    private String curDir = "C:\\root\\";
    
    public FTPServer(int port) throws IOException 
    {
        try
        {
            server = new ServerSocket(port);   
            System.out.println("Server is running");
            System.out.println("Waiting for a client ..."); 
            while(true)
            {
                socket = server.accept();
                System.out.println("Client connected...");
                dis = new DataInputStream(socket.getInputStream());
                dos = new DataOutputStream(socket.getOutputStream());
                while(true)
                {
                    String in = dis.readUTF();
                    String [] tokens = in.split(" ");
                    System.out.println(tokens[0].trim());
                    if(tokens[0].equals("logout") || tokens[0].equals("exit"))
                    {
                        break;
                    }
                    else if(tokens[0].equalsIgnoreCase("nologin"))
                    {
                        System.out.println("NO Log in");
                        dos.writeUTF("Please Login"+","+path);
                       // dos.writeUTF(path);  
                    }
                    else if(tokens[0].equals("register"))
                    {          
                        File file = new File(curDir+"users.data");    
                        if(!file.exists())    
                        {    
                            file.createNewFile();   
                        }    
                        boolean user_exists = false;    
                        BufferedReader reader = new BufferedReader(new FileReader(file));  
                        String userLine = "";    
                        String userData = "";   
                        while((userLine=reader.readLine())!=null)   
                        {   
                            userData += userLine+"\n";    
                            String[] w = userLine.split(" ");   
                            if(!(tokens[1].equals(w[0])))        
                            {    
                                user_exists = true;    
                            }     
                            System.out.println("User : "+userLine);   
                        }   
                        reader.close();     
                        userLine = tokens[1]+" "+tokens[2]+" "+tokens[4]+" "+tokens[5];   
                        if(!user_exists)   
                        {     
                            userData += userLine;    
                            BufferedWriter writer = new BufferedWriter(new FileWriter(file));    
                            writer.append(userData);     
                            writer.close();     
                            dos.writeUTF("User registered successfully"+path);    
                        }     
                        else    
                        {      
                            dos.writeUTF("User Already Exists"+path);    
                        }     
                    }      
                    else if(tokens[0].equals("login"))    
                    {     
                        String userLine="";    
                        String userData="";              
                        boolean user_exists = false;          
                        File file = new File(curDir+"users.data");          
                        BufferedReader reader = new BufferedReader(new FileReader(file));  
                        while((userLine = reader.readLine())!=null)        
                        {                                  
                            userData  += userLine+"\n";              
                            String[] w = userLine.split(" ");              
                            if((tokens[1].equals(w[0])) && (tokens[2].equals(w[1])))     
                            {                              
                                user_exists = true; 
                                login_success=true;
                            }                                         
                            // System.out.println("successfully logged in");           
                        }                             
                        reader.close();                              
                        if(user_exists)                
                        {   
                            path = "\n"+tokens[1]+"@"+curDir+":>";                    
                            System.out.println("successfully logged in");                   
                        }                                 
                        dos.writeUTF(path);                         
                    } 
                    else if(tokens[0].equals("newdir"))               
                    {                           
                        File file;                          
                        boolean exists = false;                       
                        String path2 = tokens[1];                                            
                        file = new File(curDir+path2);                 
                        //file.mkdirs();                     
                        boolean flag = false;                 
                        if(!file.exists())                 
                        {                 
                            flag = file.mkdirs();                    
                            //flag = file.createNewFile();                  
                        }                     
                        else                    
                        {                                            
                            System.out.println("Directory exists");
                            flag = false;
                        }
                        if(flag)                   
                        {                                            
                            dos.writeUTF("Directory is created : "+file.getAbsolutePath()+path); 
                        }
                        else
                        {
                            dos.writeUTF("Directory is not created"+path);
                        }  
                    }
                    else if(tokens[0].equals("list"))
                    {
                        File file = new File(curDir);
                        if(file.exists())
                    {
                            File[] arr = file.listFiles();
                            String respData = "Files and Directories in current Directory\n"; 
                            for(int i=0;i<arr.length;i++)
                            {
                                System.out.println("list files: "+arr[i]);
                                respData+=arr[i].toString()+"\n";
                            }
                            dos.writeUTF(respData+path);
                
                        }
                    }
                    else if(tokens[0].equals("changedir"))
                    {
                        File file;                          
                        boolean exists = false;                       
                        String path2 = tokens[1];
                        curDir = curDir+"\\"+path2+"\\";
                        String user[] = path.split("@");
                        path = "\n"+user[0]+"@"+curDir+":>";
                        dos.writeUTF("Directory changed\n"+path);
                    }
                    else if(tokens[0].equals("newfile"))
                    {
                        File file;
                        boolean exists = false;
                        String path2 = tokens[1];//dir name where you want to create 
                        String path3 = tokens[2];
                        //file=new File(path2);
                        String path = "C:\\root\\";
                        file = new File(path+path2);
                        System.out.println(path+path2);
                        System.out.println(file.getAbsolutePath());
                        
                        if(!file.exists())
                        {
                            file.mkdirs();                   
                        }
                        else
                        {
                            File[] arr = file.listFiles();
                            for(int i=0;i<arr.length;i++)
                            {
                                System.out.println("list files: "+arr[i]);
                            }
                            //for(File f: arr)
                                //System.out.println("list files: "+f);
                            System.out.println("Exists");
                        }
                        File file1 = new File(path+path2+"\\"+path3);
                        System.out.println(file1.getAbsoluteFile());
                        if(!file1.exists())
                        {
                            file1.createNewFile();
                            System.out.println(file1.getAbsoluteFile());
                        }
                        else
                        {
                            System.out.println("File Eixts in DIr");
                        }
                        file = new File("C:\\path2\\path3");
                        file.mkdirs();
                        if(!file.exists())
                        {
                            file.createNewFile();
                        }
                        String[] path1=path.split(":");
                        path="\n"+path1[0]+"/"+tokens[1]+"/"+tokens[2]+":\\>";
                        System.out.println(file.listFiles());
                        dos.writeUTF("file is created"+path);
                    }
                    else if(tokens[0].equals("upload")){
                        //write file checking code here
                        File file = new File(curDir+tokens[1]);
                        if(file.exists())
                        {
                            dos.writeUTF("success");
                            server1 = new ServerSocket(20);   
                            System.out.println("Server is running at port 20");
                            System.out.println("Waiting for a client ...");
                            DataOutputStream fdos = new DataOutputStream(new FileOutputStream(file));
                            while(true)
                            {
                                socket1 = server1.accept();
                                System.out.println("Client connected...");
                                dis1 = new DataInputStream(socket1.getInputStream());
                                byte [] buffer = new byte[1000];
                                while(dis1.read(buffer)>0){
                                    fdos.write(buffer);
                                }                            
                                break;
                            }
                            fdos.close();
                            socket1.close();
                            dis1.close();
                            server1.close();
                        }
                        else
                        {
                            dos.writeUTF("Failure");
                        }
                    }
                    else if(tokens[0].equals("download")){
                        //write file checking code here
                        File file = new File(curDir+tokens[1]);
                        if(file.exists())
                        {
                            dos.writeUTF("success");
                            server1 = new ServerSocket(20);   
                            System.out.println("Server is running at port 20");
                            System.out.println("Waiting for a client ...");
                            //DataInputStream fdos = new DataInputStream(socket1.getInputStream());                       

                            DataInputStream fdis = new DataInputStream(new FileInputStream(file));
                        while(true)
                        {
                            socket1 = server1.accept();
                            System.out.println("Client connected...");
                            dos1 = new DataOutputStream(socket1.getOutputStream());
                            byte [] buffer = new byte[1000];
                            while(fdis.read(buffer)>0){
                                dos1.write(buffer);
                            }            
                            //System.out.println(dos1);
                            break;
                        }
                        server1.close();
                        socket1.close();
                        dos1.close();
                        }
                        else
                        {
                            dos.writeUTF("Failure");
                        }
                    }
                    else if(tokens[0].equals("delete"))
                    {
                        dos.writeUTF("Success");
                        String fileName=tokens[1];
                        File file = new File("C:\\root\\"+tokens[1]);
                        if(file.delete())
                        {
                            dos.writeUTF("File is deleted"+path);
                            
                        }
                        else
                        {
                            dos.writeUTF("File is not deleted"+path);
                        }
                    }
                    else if(tokens[0].equals("rename"))
                    {
                        dos.writeUTF("Success");
                        String fileName=tokens[1];
                        File file1=new File("C:\\root\\"+tokens[2]);
                        File file = new File("C:\\root\\"+tokens[1]);
                        if(file.renameTo(file1))
                        {
                            dos.writeUTF("File is renamed"+path);
                            
                        }
                        else
                        {
                            dos.writeUTF("File is not renamed"+path);
                        }
                    }
                    else if(tokens[0].equals("move"))
                    {
                        dos.writeUTF("Success");
                        String fileName=tokens[1];
                        File file1=new File("C:\\root\\dir\\"+tokens[2]);
                        
                        File file = new File("C:\\root\\"+tokens[1]);
                        InputStream dis=new FileInputStream(file);
                        OutputStream dis1=new FileOutputStream(file1);
                        String st="";
                        byte[] buffer=new byte[1000];
                        int length;
                        while((length=dis.read(buffer))>0)
                        {
                            dis1.write(buffer,0,length);
                        }
                        dis.close();
                        dis1.close();
                        file.delete();
                    }
                    else if(tokens[0].equals("logout")){
                        path = "\nMSITFTP:\\>";
                        curDir = "C:\\root\\";
                    }
                    else
                    {
                        dos.writeUTF(" ,"+path); 
                    }
                }
                System.out.println("Client Disconnected");
                socket.close();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();   
        }
    }
    public static void main(String args[]) throws IOException 
    { 
       FTPServer server = new FTPServer(21); 
    } 
}